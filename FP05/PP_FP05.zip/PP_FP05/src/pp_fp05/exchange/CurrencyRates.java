/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pp_fp05.exchange;

/**
 *
 * @author Utilizador
 */
public class CurrencyRates {
    
    public static final double[][] RATES = {
        // Dólar, Euro, Iene, GBP
        { 1.00000, 0.76900, 96.1141, 0.67131 }, // Dólar
        { 1.30030, 1.00000, 124.989, 0.87290 }, // Euro
        { 96.06148, 125.00000, 1.00000, 143.26648 } // Iene
    };
}
