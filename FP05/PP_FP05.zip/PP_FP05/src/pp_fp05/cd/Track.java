/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pp_fp05.cd;

/**
 *
 * @author Utilizador
 */
public class Track {
    public int number;
    public String name;
    public int duration;
    public String authorName;

    public Track(int number, String name, int duration, String authorName) {
        this.number = number;
        this.name = name;
        this.duration = duration;
        this.authorName = authorName;
    }
}