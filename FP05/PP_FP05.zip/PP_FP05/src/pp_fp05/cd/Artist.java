/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pp_fp05.cd;

/**
 *
 * @author Utilizador
 */
public class Artist {
    public String name;
    public String birthDate;
    public String nationality;

    public Artist(String name, String birthDate, String nationality) {
        this.name = name;
        this.birthDate = birthDate;
        this.nationality = nationality;
    }
}   
