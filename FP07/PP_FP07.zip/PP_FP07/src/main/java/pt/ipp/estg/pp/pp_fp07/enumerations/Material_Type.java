package pt.ipp.estg.pp.pp_fp07.enumerations;

/**
 *
 * @author Utilizador
 */

public enum Material_Type {
    CARBONO,
    ALUMINIO
}
