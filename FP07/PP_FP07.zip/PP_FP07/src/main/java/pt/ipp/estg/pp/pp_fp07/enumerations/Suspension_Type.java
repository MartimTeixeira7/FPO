package pt.ipp.estg.pp.pp_fp07.enumerations;

/**
 *
 * @author Utilizador
 */

public enum Suspension_Type {
    SIMPLES,
    DUPLA,
    SEM_SUSPENSAO
}
