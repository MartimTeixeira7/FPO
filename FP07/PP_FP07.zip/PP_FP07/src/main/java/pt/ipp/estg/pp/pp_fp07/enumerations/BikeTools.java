package pt.ipp.estg.pp.pp_fp07.enumerations;

/**
 *
 * @author Utilizador
 */

public enum BikeTools {
    GARRAFA_AGUA,
    KIT_REPARACAO_PNEU,
    CONTA_QUILOMETROS,
    ALFORJE,
    SUPORTE_TELEMOVEL
}
