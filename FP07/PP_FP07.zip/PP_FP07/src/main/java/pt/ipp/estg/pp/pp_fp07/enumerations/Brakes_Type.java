package pt.ipp.estg.pp.pp_fp07.enumerations;

/**
 *
 * @author Utilizador
 */

public enum Brakes_Type {
    PINCAS,
    HIDRAULICOS
}
