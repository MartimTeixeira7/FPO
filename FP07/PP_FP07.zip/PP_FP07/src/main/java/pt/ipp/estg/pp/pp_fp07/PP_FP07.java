/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pt.ipp.estg.pp.pp_fp07;

/**
 *
 * @author Utilizador
 */
public class PP_FP07 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
