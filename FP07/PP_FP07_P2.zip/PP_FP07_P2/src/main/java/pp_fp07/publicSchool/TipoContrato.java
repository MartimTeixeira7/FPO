/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pp_fp07.publicSchool;

/**
 *
 * @author Utilizador
 */
public enum TipoContrato {
    PARCIAL,
    INTEGRAL
}
